# Third-party components

The project uses AndroidX Activity Compose, Jetpack Compose Material 3, AndroidX Core, and AndroidX Lifecycle libraries through Maven dependencies. These libraries are published under their respective open-source licenses, generally Apache License 2.0. Review each dependency's license and notices before redistributing a release.
