package com.amphotostudio

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.toArgb
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Orange = Color(0xFFFF7A1A)
private val Dark = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AMPhotoApp() }
    }
}

private data class EditState(
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val rotation: Float = 0f,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val text: String = "",
    val textColor: Int = AndroidColor.WHITE,
    val textSize: Float = 48f
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AMPhotoApp() {
    val context = LocalContext.current
    var darkMode by remember { mutableStateOf(true) }
    val scheme = if (darkMode) darkColorScheme(
        primary = Orange, background = Dark, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    ) else lightColorScheme(primary = Orange)

    var original by remember { mutableStateOf<Bitmap?>(null) }
    var state by remember { mutableStateOf(EditState()) }
    val history = remember { mutableStateListOf<EditState>() }
    var showExport by remember { mutableStateOf(false) }
    var exportFormat by remember { mutableStateOf("JPEG") }
    var showTextDialog by remember { mutableStateOf(false) }
    var textDraft by remember { mutableStateOf("") }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }

    fun change(transform: (EditState) -> EditState) {
        history.add(state)
        if (history.size > 30) history.removeAt(0)
        state = transform(state)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    val maxDim = max(opts.outWidth, opts.outHeight).coerceAtLeast(1)
                    var sample = 1
                    while (maxDim / sample > 2400) sample *= 2
                    val bitmap = BitmapFactory.Options().run {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, this) }
                    }
                    if (bitmap != null) {
                        original = bitmap
                        state = EditState()
                        history.clear()
                        zoom = 1f
                        pan = Offset.Zero
                    } else Toast.makeText(context, "تعذّر فتح الصورة", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "تعذّر فتح الصورة: ${e.localizedMessage ?: ""}", Toast.LENGTH_LONG).show()
            }
        }
    }

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("AM Photo Studio", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text("استوديو الصور", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
                        }
                    },
                    actions = {
                        IconButton(onClick = { darkMode = !darkMode }) {
                            Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "تغيير المظهر")
                        }
                        IconButton(onClick = { if (original != null) showExport = true else picker.launch("image/*") }) {
                            Icon(Icons.Default.FileDownload, "تصدير")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                if (original == null) {
                    Spacer(Modifier.height(20.dp))
                    Box(
                        Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(28.dp))
                            .background(BrushCompat.surface(darkMode))
                            .border(1.dp, Orange.copy(alpha=.45f), RoundedCornerShape(28.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AddPhotoAlternate, null, tint = Orange, modifier = Modifier.size(58.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("ابدأ بتحرير صورك", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("اختر صورة من جهازك للبدء", color = MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
                            Spacer(Modifier.height(18.dp))
                            Button(onClick = { picker.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                                Icon(Icons.Default.PhotoLibrary, null)
                                Spacer(Modifier.width(8.dp))
                                Text("ابدأ التعديل")
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("أدوات سريعة", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickTile("تعديل صورة", Icons.Default.Tune, Modifier.weight(1f)) { picker.launch("image/*") }
                        QuickTile("إضافة نص", Icons.Default.TextFields, Modifier.weight(1f)) {
                            picker.launch("image/*")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickTile("دمج الصور", Icons.Default.Layers, Modifier.weight(1f)) {
                            Toast.makeText(context, "ميزة دمج الصور متعددة الطبقات قيد التطوير", Toast.LENGTH_SHORT).show()
                        }
                        QuickTile("قوالب التصميم", Icons.Default.Dashboard, Modifier.weight(1f)) {
                            Toast.makeText(context, "القوالب الجاهزة ستضاف في تحديث لاحق", Toast.LENGTH_SHORT).show()
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("مصمم للصور التي تحبها", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Spacer(Modifier.height(6.dp))
                            Text("تحرير محلي، تحكم بالألوان، تدوير، نصوص وتصدير بجودة عالية.",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha=.7f))
                        }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("مساحة العمل", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                        Text("${original!!.width} × ${original!!.height}", color = MaterialTheme.colorScheme.onSurface.copy(alpha=.65f), fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier.fillMaxWidth().heightIn(min = 240.dp, max = 390.dp)
                            .clip(RoundedCornerShape(20.dp)).background(Color(0xFF090A0C)),
                        contentAlignment = Alignment.Center
                    ) {
                        val edited = remember(original, state) { renderBitmap(original!!, state, false) }
                        Image(
                            bitmap = edited.asImageBitmap(),
                            contentDescription = "معاينة الصورة",
                            modifier = Modifier.fillMaxSize().padding(8.dp)
                                .pointerInput(Unit) {
                                    detectTransformGestures { _, panChange, zoomChange, _ ->
                                        zoom = (zoom * zoomChange).coerceIn(1f, 4f)
                                        pan += panChange
                                    }
                                },
                            contentScale = ContentScale.Fit
                        )
                        if (zoom > 1.01f) {
                            Surface(Modifier.align(Alignment.BottomEnd).padding(10.dp), color=Color.Black.copy(alpha=.65f), shape=RoundedCornerShape(10.dp)) {
                                Text("تكبير ${(zoom*100).toInt()}%", Modifier.padding(horizontal=8.dp, vertical=4.dp), color=Color.White, fontSize=11.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { if (history.isNotEmpty()) state = history.removeAt(history.lastIndex) }, modifier=Modifier.weight(1f)) {
                            Icon(Icons.Default.Undo, null); Spacer(Modifier.width(4.dp)); Text("تراجع")
                        }
                        OutlinedButton(onClick = { change { it.copy(rotation = (it.rotation + 90f) % 360f) } }, modifier=Modifier.weight(1f)) {
                            Icon(Icons.Default.RotateRight, null); Spacer(Modifier.width(4.dp)); Text("تدوير")
                        }
                        OutlinedButton(onClick = { state = EditState(); history.clear(); zoom=1f; pan=Offset.Zero }, modifier=Modifier.weight(1f)) {
                            Icon(Icons.Default.RestartAlt, null); Spacer(Modifier.width(4.dp)); Text("إعادة")
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("ضبط الصورة", fontSize=18.sp, fontWeight=FontWeight.Bold)
                    SliderControl("السطوع", state.brightness, -100f, 100f, { v -> change { it.copy(brightness=v) } }, "${state.brightness.toInt()}")
                    SliderControl("التباين", state.contrast, 0.3f, 2.5f, { v -> change { it.copy(contrast=v) } }, String.format("%.1f", state.contrast))
                    SliderControl("التشبع", state.saturation, 0f, 2.5f, { v -> change { it.copy(saturation=v) } }, String.format("%.1f", state.saturation))
                    Spacer(Modifier.height(8.dp))
                    Text("التحويل والعناصر", fontSize=18.sp, fontWeight=FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick={change{it.copy(flipH=!it.flipH)}}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.Flip, null); Text("عكس أفقي") }
                        OutlinedButton(onClick={change{it.copy(flipV=!it.flipV)}}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.FlipCameraAndroid, null); Text("عكس عمودي") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                        Button(onClick={ textDraft=state.text; showTextDialog=true }, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=Orange)) {
                            Icon(Icons.Default.TextFields, null); Text("إضافة نص")
                        }
                        OutlinedButton(onClick={showExport=true}, modifier=Modifier.weight(1f)) {
                            Icon(Icons.Default.SaveAlt, null); Text("حفظ وتصدير")
                        }
                    }
                    if (state.text.isNotBlank()) {
                        Text("النص: ${state.text}", modifier=Modifier.padding(top=8.dp), color=MaterialTheme.colorScheme.onSurface.copy(alpha=.7f))
                        SliderControl("حجم النص", state.textSize, 16f, 100f, { v -> change { it.copy(textSize=v) } }, "${state.textSize.toInt()}")
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            listOf(AndroidColor.WHITE, AndroidColor.BLACK, AndroidColor.RED, AndroidColor.YELLOW, AndroidColor.CYAN).forEach { color ->
                                Surface(
                                    modifier=Modifier.size(34.dp).clip(RoundedCornerShape(17.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha=.3f), RoundedCornerShape(17.dp)),
                                    color=Color(color),
                                    onClick={change{it.copy(textColor=color)}}
                                ) {}
                            }
                        }
                    }
                    Spacer(Modifier.height(22.dp))
                }
            }
        }

        if (showTextDialog) {
            AlertDialog(
                onDismissRequest={showTextDialog=false},
                title={Text("إضافة نص إلى الصورة")},
                text={
                    OutlinedTextField(value=textDraft, onValueChange={textDraft=it}, label={Text("النص بالعربية أو الإنجليزية")}, singleLine=false)
                },
                confirmButton={ TextButton(onClick={change{it.copy(text=textDraft)}; showTextDialog=false}) { Text("إضافة", color=Orange) } },
                dismissButton={TextButton(onClick={showTextDialog=false}) { Text("إلغاء")}}
            )
        }

        if (showExport) {
            AlertDialog(
                onDismissRequest={showExport=false},
                title={Text("تصدير الصورة")},
                text={
                    Column {
                        Text("اختر صيغة الملف:")
                        Spacer(Modifier.height(8.dp))
                        listOf("JPEG", "PNG", "WEBP").forEach { format ->
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                RadioButton(selected=exportFormat==format, onClick={exportFormat=format}, colors=RadioButtonDefaults.colors(selectedColor=Orange))
                                Text(format)
                            }
                        }
                        Text("ستُحفظ الصورة في مجلد Pictures/AM Photo Studio.", fontSize=12.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.7f))
                    }
                },
                confirmButton={
                    TextButton(onClick={
                        val src = original
                        if (src != null) {
                            try {
                                val bitmap = renderBitmap(src, state, true)
                                val mime = when(exportFormat) { "PNG" -> "image/png"; "WEBP" -> "image/webp"; else -> "image/jpeg" }
                                val ext = when(exportFormat) { "PNG" -> "png"; "WEBP" -> "webp"; else -> "jpg" }
                                val values = ContentValues().apply {
                                    put(MediaStore.Images.Media.DISPLAY_NAME, "AM_Photo_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.$ext")
                                    put(MediaStore.Images.Media.MIME_TYPE, mime)
                                    if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AM Photo Studio")
                                }
                                val resolver = context.contentResolver
                                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                                if (uri != null) {
                                    resolver.openOutputStream(uri)?.use { out ->
                                        val format = when(exportFormat) {
                                            "PNG" -> Bitmap.CompressFormat.PNG
                                            "WEBP" -> if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                                            else -> Bitmap.CompressFormat.JPEG
                                        }
                                        val quality = if (exportFormat == "PNG") 100 else 95
                                        bitmap.compress(format, quality, out)
                                    }
                                    Toast.makeText(context, "تم حفظ الصورة بنجاح", Toast.LENGTH_LONG).show()
                                } else Toast.makeText(context, "تعذّر إنشاء ملف الصورة", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "فشل التصدير: ${e.localizedMessage ?: ""}", Toast.LENGTH_LONG).show()
                            }
                        }
                        showExport=false
                    }) { Text("تصدير", color=Orange) }
                },
                dismissButton={TextButton(onClick={showExport=false}) { Text("إلغاء")}}
            )
        }
    }
}

private object BrushCompat {
    fun surface(dark: Boolean) = if (dark) Color(0xFF1B1D22) else Color(0xFFF2F2F4)
}

@Composable
private fun QuickTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier=modifier, onClick=onClick, shape=RoundedCornerShape(18.dp),
        colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(vertical=18.dp, horizontal=10.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Icon(icon, null, tint=Orange, modifier=Modifier.size(28.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight=FontWeight.Medium)
        }
    }
}

@Composable
private fun SliderControl(label: String, value: Float, min: Float, max: Float, onValue: (Float)->Unit, display: String) {
    Column(Modifier.fillMaxWidth().padding(top=4.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text(label, modifier=Modifier.weight(1f), color=MaterialTheme.colorScheme.onSurface.copy(alpha=.85f))
            Text(display, color=Orange, fontSize=13.sp)
        }
        Slider(value=value, onValueChange=onValue, valueRange=min..max, colors=SliderDefaults.colors(thumbColor=Orange, activeTrackColor=Orange))
    }
}

private fun renderBitmap(source: Bitmap, state: EditState, includeText: Boolean): Bitmap {
    val matrix = Matrix()
    val sx = if (state.flipH) -1f else 1f
    val sy = if (state.flipV) -1f else 1f
    matrix.postScale(sx, sy, source.width / 2f, source.height / 2f)
    matrix.postRotate(state.rotation, source.width / 2f, source.height / 2f)
    val transformed = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    val output = Bitmap.createBitmap(transformed.width, transformed.height, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(output)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    val sat = state.saturation
    val contrast = state.contrast
    val brightness = state.brightness * 2.55f
    val cm = android.graphics.ColorMatrix(floatArrayOf(
        0.213f + 0.787f*sat, 0.715f - 0.715f*sat, 0.072f - 0.072f*sat, 0f, 0f,
        0.213f - 0.213f*sat, 0.715f + 0.285f*sat, 0.072f - 0.072f*sat, 0f, 0f,
        0.213f - 0.213f*sat, 0.715f - 0.715f*sat, 0.072f + 0.928f*sat, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    ))
    val contrastMatrix = android.graphics.ColorMatrix(floatArrayOf(
        contrast,0f,0f,0f,brightness+128f*(1-contrast),
        0f,contrast,0f,0f,brightness+128f*(1-contrast),
        0f,0f,contrast,0f,brightness+128f*(1-contrast),
        0f,0f,0f,1f,0f
    ))
    cm.postConcat(contrastMatrix)
    paint.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
    canvas.drawBitmap(transformed, 0f, 0f, paint)
    if (includeText && state.text.isNotBlank()) {
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = state.textColor
            textSize = state.textSize * (source.width / 1080f).coerceAtLeast(.5f)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            setShadowLayer(4f, 2f, 2f, AndroidColor.BLACK)
            textAlign = Paint.Align.CENTER
        }
        val x = output.width / 2f
        val y = output.height * .85f
        // Android Canvas uses the device's native text layout, including RTL scripts.
        canvas.drawText(state.text, x, y, textPaint)
    }
    if (transformed !== source && !transformed.isRecycled) transformed.recycle()
    return output
}
